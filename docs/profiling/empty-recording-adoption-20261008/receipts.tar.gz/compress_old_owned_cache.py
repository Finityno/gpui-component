from pathlib import Path
import tomllib,glob,json,hashlib,gzip,sys
r=Path(__file__).parent;w=Path('/workspace/fincode-gpui');root=tomllib.loads((w/'Cargo.toml').read_text());names=set()
for pattern in root['workspace']['members']:
 for folder in glob.glob(str(w/pattern)):
  p=Path(folder)/'Cargo.toml'
  if p.is_file():names.add(tomllib.loads(p.read_text())['package']['name'].replace('-','_'))
names.update(['gpui','gpui_platform','gpui_linux','gpui_apple','gpui_macos','gpui_windows','gpui_shared_string','gpui_util','gpui_component','gpui_component_macros','sum_tree','collections','http_client','derive_refineable','refineable','scheduler','zlog','ztracing','perf','util_macros'])
files=[p for p in (w/'target/debug/deps').iterdir() if p.suffix in ['.rmeta','.rlib'] and p.name.startswith('lib') and p.name[3:].split('-',1)[0] in names];rows=[]
for p in files:
 raw=p.read_bytes();compressed=gzip.compress(raw,compresslevel=1,mtime=0)
 if len(compressed)>=len(raw):continue
 q=Path(str(p)+'.gz');assert not q.exists();st=p.stat();assert gzip.decompress(compressed)==raw;q.write_bytes(compressed);rows.append({'original_path':str(p),'compressed_path':str(q),'original_bytes':len(raw),'compressed_bytes':len(compressed),'original_sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':hashlib.sha256(compressed).hexdigest(),'mode':st.st_mode,'mtime_ns':st.st_mtime_ns});p.unlink()
x={'scope':'Completed prior owned integration cache only: workspace/GPUI rlib and rmeta files. Exact bytes preserved in gzip/roundtrip hashes, restore by decompress to original path before reusing prior cache. All native executables, proc macro/shared libraries, immutable benchmark59externs, sources and raw samples untouched. These files are Cargo compile caches; no measured native artifact removed.','files':rows,'saved_bytes':sum(a['original_bytes']-a['compressed_bytes'] for a in rows)};(r/sys.argv[1]).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'files':len(rows),'saved_bytes':x['saved_bytes']}))
