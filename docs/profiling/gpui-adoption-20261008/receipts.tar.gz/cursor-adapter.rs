#[path = "blink-cursor-regression-before.rs"]
mod cursor;
