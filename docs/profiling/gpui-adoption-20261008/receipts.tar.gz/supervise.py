import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--seconds', type=int, required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--cwd', required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[0] == '--' else args.command
root = Path(__file__).parent
start = time.time()
receipt = {'command': command, 'cwd': args.cwd, 'deadline_seconds': args.seconds, 'started_unix': start}
with (root / (args.name + '.log')).open('wb') as output:
    child = subprocess.Popen(command, cwd=args.cwd, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    receipt['pid'] = child.pid
    try:
        code = child.wait(timeout=args.seconds)
        receipt['timed_out'] = False
    except subprocess.TimeoutExpired:
        receipt['timed_out'] = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
receipt.update({'exit_code': code, 'elapsed_seconds': time.time() - start, 'log_sha256': hashlib.sha256((root / (args.name + '.log')).read_bytes()).hexdigest()})
(root / (args.name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
raise SystemExit(code if code >= 0 else 128 - code)
