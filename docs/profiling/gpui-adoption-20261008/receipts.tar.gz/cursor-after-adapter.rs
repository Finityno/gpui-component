#[path = "blink-cursor-after.rs"]
mod cursor;
